# KEIL5 美化界面

#### 介绍
keil5 代码美化主题，仿Vscode



#### 使用说明

1、找到安装Keil路径;\
2、在UV4目录下的global.prop文件;\
3、替换这个文件就可以了
